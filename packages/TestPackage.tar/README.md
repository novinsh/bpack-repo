BHumanCodeRelease
=================

The official 2016 B-Human code release. 

The 2015 code release is tagged with "coderelease2015".

The 2014 code release is tagged with "coderelease2014".

The 2013 code release is tagged with "coderelease2013".
